package org.iesalixar.servidor.model;

import java.io.Serializable;

public class ProductLines implements Serializable {
	
	private String productLine;
	
	public ProductLines() {
		// TODO Auto-generated constructor stub
	}

	public String getProductLine() {
		return productLine;
	}

	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}
	
	

}
