package org.iesalixar.servidor.dao;

import org.iesalixar.servidor.model.Oficina;

public interface DAOOficina {
	
	public Oficina getOficina(String searchTerm);

}
