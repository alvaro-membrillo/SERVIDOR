package org.iesalixar.servidor.dto;

public class GradoDTO {

	private String nombre;

	public GradoDTO() {
		// TODO Auto-generated constructor stub
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

}
