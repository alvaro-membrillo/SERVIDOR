package org.iesalixar.servidor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecuperacionFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecuperacionFinalApplication.class, args);
	}

}
